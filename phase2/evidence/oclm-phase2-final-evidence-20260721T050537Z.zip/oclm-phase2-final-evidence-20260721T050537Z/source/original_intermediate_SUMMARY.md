# OCLM Phase 1 88検査・一斉敵対監査結果

- 総検査数: **88/88**
- 攻撃 SURVIVES: **76/80**
  - 第一波: **31/32**
  - 第二波: **45/48**
- 攻撃 BROKEN: **0/80**
- 攻撃 UNVERIFIED: **4/80**
- 健全性 PASS: **8/8**
- 健全性 FAIL/UNVERIFIED: **0/8**
- 総合判定: **FAIL / UNVERIFIED**

## 判定規則

- 攻撃query `verified` → 反例traceあり → **BROKEN**
- 攻撃query `falsified` → 反例traceなし → **SURVIVES**
- timeout / parse error / analysis incomplete → **UNVERIFIED**
- 健全性query `verified` → 正規または想定ライフサイクル到達可能 → **REACHABLE**

## 全88検査

| ID | 種別 | 系統 | モデル | 対象 | 判定 | 秒 |
|---|---|---|---|---|---:|---:|
| A01 | attack | 系譜・同一性置換 | `oclm_phase1.spthy` | `child_lineage_is_bound` | **SURVIVES** | 1.877 |
| A02 | attack | 系譜・同一性置換 | `oclm_phase1b1_external_signature.spthy` | `external_child_identity_is_bound_or_compromised` | **SURVIVES** | 4.677 |
| A03 | attack | 系譜・同一性置換 | `oclm_phase1c2_signed_composition_certificate.spthy` | `signed_composition_identity_is_bound_or_compromised` | **SURVIVES** | 21.914 |
| A04 | attack | 系譜・同一性置換 | `oclm_phase1c3b_c2_c3_composition_contract.spthy` | `forward_secure_composed_identity_is_bound_or_compromised` | **SURVIVES** | 94.034 |
| A05 | attack | Cross-instance・祖先混成 | `oclm_phase1.spthy` | `generated_child_has_full_ancestry` | **SURVIVES** | 1.396 |
| A06 | attack | Cross-instance・祖先混成 | `oclm_phase1c1_composition_contract.spthy` | `uncompromised_acceptance_has_full_composed_ancestry` | **SURVIVES** | 4.438 |
| A07 | attack | Cross-instance・祖先混成 | `oclm_phase1c2_signed_composition_certificate.spthy` | `uncompromised_signed_acceptance_has_full_ancestry` | **SURVIVES** | 8.352 |
| A08 | attack | Cross-instance・祖先混成 | `oclm_phase1c3b_c2_c3_composition_contract.spthy` | `uncompromised_composed_acceptance_has_full_ancestry` | **SURVIVES** | 29.63 |
| A09 | attack | Replay・単回性・stale・rollback | `oclm_phase1.spthy` | `complementary_pair_is_single_use` | **SURVIVES** | 2.834 |
| A10 | attack | Replay・単回性・stale・rollback | `oclm_phase1b2_time_space_window.spthy` | `window_generates_at_most_once` | **SURVIVES** | 2.751 |
| A11 | attack | Replay・単回性・stale・rollback | `oclm_phase1c4a_verifier_state_monotonicity_core.spthy` | `rollback_attempt_cannot_lower_state_without_later_compromise` | **SURVIVES** | 0.232 |
| A12 | attack | Replay・単回性・stale・rollback | `oclm_phase1c4b_rollback_resistant_composition_contract.spthy` | `stale_composed_acceptance_requires_prior_verifier_compromise` | **SURVIVES** | 1.601 |
| A13 | attack | 鍵侵害の時間境界 | `oclm_phase1c3_forward_secure_epochs.spthy` | `erased_epoch_key_cannot_be_compromised_later` | **SURVIVES** | 15.246 |
| A14 | attack | 鍵侵害の時間境界 | `oclm_phase1c3_forward_secure_epochs.spthy` | `accepted_epoch_credential_requires_issuance_or_root_compromise` | **UNVERIFIED** | 1800.667 |
| A15 | attack | 鍵侵害の時間境界 | `oclm_phase1c3a_forward_secure_epoch_core.spthy` | `accepted_old_certificate_requires_issuance_or_target_compromise` | **SURVIVES** | 1.868 |
| A16 | attack | 鍵侵害の時間境界 | `oclm_phase1c3b_c2_c3_composition_contract.spthy` | `composed_acceptance_requires_contract_or_target_compromise` | **SURVIVES** | 27.914 |
| A17 | attack | 失効・再有効化 | `oclm_phase1c5a_revocation_state_core.spthy` | `certificate_reactivation_requires_prior_authority_compromise` | **SURVIVES** | 0.846 |
| A18 | attack | 失効・再有効化 | `oclm_phase1c5a_revocation_state_core.spthy` | `current_verifier_state_never_accepts_revoked_certificate` | **SURVIVES** | 0.59 |
| A19 | attack | 失効・再有効化 | `oclm_phase1c5a_revocation_state_core.spthy` | `revoked_acceptance_requires_missing_update_or_verifier_compromise` | **SURVIVES** | 0.9 |
| A20 | attack | 失効・再有効化 | `oclm_phase1c5c_revocation_transparency_lineage_composition_contract.spthy` | `revoked_composed_acceptance_requires_explicit_exception` | **SURVIVES** | 3.26 |
| A21 | attack | Transparency・split-view | `oclm_phase1c5b_transparency_split_view_core.spthy` | `accepted_checkpoint_requires_matching_issuance` | **SURVIVES** | 1.273 |
| A22 | attack | Transparency・split-view | `oclm_phase1c5b_transparency_split_view_core.spthy` | `conflicting_checkpoint_roots_require_prior_log_compromise` | **SURVIVES** | 0.98 |
| A23 | attack | Transparency・split-view | `oclm_phase1c5b_transparency_split_view_core.spthy` | `same_certificate_conflicting_transparency_histories_require_compromise` | **SURVIVES** | 1.095 |
| A24 | attack | Transparency・split-view | `oclm_phase1c5c_revocation_transparency_lineage_composition_contract.spthy` | `conflicting_composed_roots_require_prior_log_compromise` | **SURVIVES** | 4.795 |
| A25 | attack | Time・Space・Oracle結合 | `oclm_phase1b_external.spthy` | `external_acceptance_requires_issue_or_compromise` | **SURVIVES** | 8.88 |
| A26 | attack | Time・Space・Oracle結合 | `oclm_phase1b2_time_space_window.spthy` | `generated_child_has_open_window_ancestry` | **SURVIVES** | 2.211 |
| A27 | attack | Time・Space・Oracle結合 | `oclm_phase1c1_composition_contract.spthy` | `composed_acceptance_requires_closed_generation_or_compromise` | **SURVIVES** | 3.658 |
| A28 | attack | Time・Space・Oracle結合 | `oclm_phase1c2_signed_composition_certificate.spthy` | `signed_acceptance_requires_certificate_or_compromise` | **SURVIVES** | 6.913 |
| A29 | attack | 最終合成・canonical競合 | `oclm_phase1c5c_revocation_transparency_lineage_composition_contract.spthy` | `composed_acceptance_requires_all_verified_component_contracts` | **SURVIVES** | 2.248 |
| A30 | attack | 最終合成・canonical競合 | `oclm_phase1c6a_multi_epoch_generalization_core.spthy` | `accepted_epoch_requires_matching_prior_issuance` | **SURVIVES** | 1.109 |
| A31 | attack | 最終合成・canonical競合 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `generalized_acceptance_requires_c5c_and_c6a_contracts` | **SURVIVES** | 11.179 |
| A32 | attack | 最終合成・canonical競合 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `conflicting_generalized_epoch_histories_require_prior_compromise` | **SURVIVES** | 13.094 |
| A33 | attack | 理論・同一性・祖先 | `oclm_phase1.spthy` | `accepted_child_was_generated` | **SURVIVES** | 1.78 |
| A34 | attack | 合成・証拠境界 | `oclm_phase1.spthy` | `oracle_equivocation_is_evidenced` | **SURVIVES** | 1.387 |
| A35 | attack | 理論・同一性・祖先 | `oclm_phase1b1_external_signature.spthy` | `external_child_requires_generation_or_compromise` | **SURVIVES** | 2.105 |
| A36 | attack | 理論・同一性・祖先 | `oclm_phase1b2_time_space_window.spthy` | `generated_child_precedes_matching_close` | **SURVIVES** | 2.212 |
| A37 | attack | 理論・同一性・祖先 | `oclm_phase1b2_time_space_window.spthy` | `generated_parent_a_precedes_close` | **SURVIVES** | 2.289 |
| A38 | attack | 理論・同一性・祖先 | `oclm_phase1b2_time_space_window.spthy` | `generated_parent_b_precedes_close` | **SURVIVES** | 2.642 |
| A39 | attack | 理論・同一性・祖先 | `oclm_phase1b3_claim_collapse.spthy` | `post_collapse_acceptance_requires_generation_or_compromise` | **SURVIVES** | 2.992 |
| A40 | attack | 理論・同一性・祖先 | `oclm_phase1b3_claim_collapse.spthy` | `post_collapse_acceptance_has_collapse_ancestry` | **SURVIVES** | 2.625 |
| A41 | attack | 理論・同一性・祖先 | `oclm_phase1b3_claim_collapse.spthy` | `post_collapse_child_identity_is_bound_or_compromised` | **SURVIVES** | 6.953 |
| A42 | attack | 理論・同一性・祖先 | `oclm_phase1b_external.spthy` | `external_acceptance_requires_generation_or_compromise` | **SURVIVES** | 10.235 |
| A43 | attack | 理論・同一性・祖先 | `oclm_phase1b_external.spthy` | `external_child_lineage_is_bound_or_compromised` | **SURVIVES** | 85.809 |
| A44 | attack | 敵対的意味論 | `oclm_phase1b_external.spthy` | `external_model_pair_is_single_use` | **SURVIVES** | 9.295 |
| A45 | attack | 理論・同一性・祖先 | `oclm_phase1c1_composition_contract.spthy` | `composed_child_identity_is_bound_or_compromised` | **SURVIVES** | 8.14 |
| A46 | attack | 時間境界・状態遷移 | `oclm_phase1c3_forward_secure_epochs.spthy` | `accepted_certificate_with_issued_credential_requires_origin_or_epoch_compromise` | **UNVERIFIED** | 1800.6 |
| A47 | attack | 理論・同一性・祖先 | `oclm_phase1c3_forward_secure_epochs.spthy` | `uncompromised_erased_epoch_acceptance_has_full_ancestry` | **UNVERIFIED** | 1800.157 |
| A48 | attack | 理論・同一性・祖先 | `oclm_phase1c3_forward_secure_epochs.spthy` | `past_epoch_identity_is_bound_or_target_compromised` | **UNVERIFIED** | 1801.13 |
| A49 | attack | 時間境界・状態遷移 | `oclm_phase1c3a_forward_secure_epoch_core.spthy` | `erased_old_epoch_key_cannot_be_compromised_later` | **SURVIVES** | 2.792 |
| A50 | attack | 時間境界・状態遷移 | `oclm_phase1c3a_forward_secure_epoch_core.spthy` | `accepted_epoch_credential_requires_issuance_or_root_compromise` | **SURVIVES** | 1.3 |
| A51 | attack | 時間境界・状態遷移 | `oclm_phase1c4a_verifier_state_monotonicity_core.spthy` | `verifier_state_e1_never_rolls_back_to_e0_without_compromise` | **SURVIVES** | 0.168 |
| A52 | attack | 時間境界・状態遷移 | `oclm_phase1c4a_verifier_state_monotonicity_core.spthy` | `verifier_state_e2_never_rolls_back_to_e1_without_compromise` | **SURVIVES** | 0.184 |
| A53 | attack | 時間境界・状態遷移 | `oclm_phase1c4a_verifier_state_monotonicity_core.spthy` | `verifier_state_e2_never_rolls_back_to_e0_without_compromise` | **SURVIVES** | 0.174 |
| A54 | attack | 時間境界・状態遷移 | `oclm_phase1c4b_rollback_resistant_composition_contract.spthy` | `rollback_resistant_acceptance_requires_c3b_contract` | **SURVIVES** | 1.378 |
| A55 | attack | 時間境界・状態遷移 | `oclm_phase1c4b_rollback_resistant_composition_contract.spthy` | `composed_acceptance_uses_latest_state_or_prior_verifier_compromise` | **SURVIVES** | 1.563 |
| A56 | attack | 合成・証拠境界 | `oclm_phase1c4b_rollback_resistant_composition_contract.spthy` | `same_contract_conflicting_verifier_histories_require_compromise` | **SURVIVES** | 1.444 |
| A57 | attack | 時間境界・状態遷移 | `oclm_phase1c5a_revocation_state_core.spthy` | `verifier_revocation_state_never_rolls_back_without_compromise` | **SURVIVES** | 0.592 |
| A58 | attack | Transparency・分岐 | `oclm_phase1c5b_transparency_split_view_core.spthy` | `conflicting_gossip_produces_equivocation_evidence` | **SURVIVES** | 0.413 |
| A59 | attack | 合成・証拠境界 | `oclm_phase1c5c_revocation_transparency_lineage_composition_contract.spthy` | `clean_composed_acceptance_has_current_component_evidence` | **SURVIVES** | 1.637 |
| A60 | attack | Transparency・分岐 | `oclm_phase1c5c_revocation_transparency_lineage_composition_contract.spthy` | `forked_composed_acceptance_requires_prior_log_compromise` | **SURVIVES** | 1.902 |
| A61 | attack | 理論・同一性・祖先 | `oclm_phase1c5c_revocation_transparency_lineage_composition_contract.spthy` | `stale_lineage_composed_acceptance_requires_prior_compromise` | **SURVIVES** | 1.594 |
| A62 | attack | 時間境界・状態遷移 | `oclm_phase1c6a_multi_epoch_generalization_core.spthy` | `current_epoch_acceptance_has_current_evidence` | **SURVIVES** | 0.778 |
| A63 | attack | 時間境界・状態遷移 | `oclm_phase1c6a_multi_epoch_generalization_core.spthy` | `stale_epoch_acceptance_requires_prior_verifier_compromise` | **SURVIVES** | 0.793 |
| A64 | attack | 時間境界・状態遷移 | `oclm_phase1c6a_multi_epoch_generalization_core.spthy` | `generalized_epoch_rollback_requires_prior_verifier_compromise` | **SURVIVES** | 0.774 |
| A65 | attack | 時間境界・状態遷移 | `oclm_phase1c6a_multi_epoch_generalization_core.spthy` | `recorded_epoch_transition_never_rolls_back_without_compromise` | **SURVIVES** | 0.842 |
| A66 | attack | 時間境界・状態遷移 | `oclm_phase1c6a_multi_epoch_generalization_core.spthy` | `conflicting_direct_epoch_acceptances_require_prior_compromise` | **SURVIVES** | 0.88 |
| A67 | attack | 合成・証拠境界 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `clean_generalized_acceptance_has_complete_evidence` | **SURVIVES** | 17.402 |
| A68 | attack | 時間境界・状態遷移 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `stale_generalized_acceptance_has_stale_epoch_evidence` | **SURVIVES** | 9.522 |
| A69 | attack | 時間境界・状態遷移 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `stale_generalized_acceptance_uses_epoch_compromise_state` | **SURVIVES** | 8.513 |
| A70 | attack | 時間境界・状態遷移 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `generalized_epoch_compromise_use_requires_prior_compromise` | **SURVIVES** | 12.68 |
| A71 | attack | 失効・再有効化 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `revoked_generalized_acceptance_requires_explicit_exception` | **SURVIVES** | 10.374 |
| A72 | attack | Transparency・分岐 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `forked_generalized_acceptance_requires_prior_log_compromise` | **SURVIVES** | 12.537 |
| A73 | attack | Transparency・分岐 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `conflicting_generalized_transparency_roots_require_prior_compromise` | **SURVIVES** | 20.581 |
| A74 | attack | 完全複製・逆方向同一性 | `oclm_phase1.spthy` | `audit_a74_same_provenance_distinct_child` | **SURVIVES** | 2.376 |
| A75 | attack | 完全複製・逆方向同一性 | `oclm_phase1b1_external_signature.spthy` | `audit_a75_same_provenance_distinct_child` | **SURVIVES** | 1.425 |
| A76 | attack | 完全複製・逆方向同一性 | `oclm_phase1b3_claim_collapse.spthy` | `audit_a76_same_provenance_distinct_child` | **SURVIVES** | 2.368 |
| A77 | attack | 完全複製・逆方向同一性 | `oclm_phase1b_external.spthy` | `audit_a77_same_provenance_distinct_child` | **SURVIVES** | 5.301 |
| A78 | attack | 完全複製・逆方向同一性 | `oclm_phase1c1_composition_contract.spthy` | `audit_a78_same_provenance_distinct_child` | **SURVIVES** | 5.24 |
| A79 | attack | 完全複製・逆方向同一性 | `oclm_phase1c2_signed_composition_certificate.spthy` | `audit_a79_same_provenance_distinct_child` | **SURVIVES** | 5.203 |
| A80 | attack | 完全複製・逆方向同一性 | `oclm_phase1c3b_c2_c3_composition_contract.spthy` | `audit_a80_same_provenance_distinct_child` | **SURVIVES** | 41.682 |
| H01 | health | モデル健全性 | `oclm_phase1.spthy` | `executable` | **REACHABLE** | 3.363 |
| H02 | health | モデル健全性 | `oclm_phase1b2_time_space_window.spthy` | `executable_complete_window_lifecycle` | **REACHABLE** | 4.92 |
| H03 | health | モデル健全性 | `oclm_phase1c2_signed_composition_certificate.spthy` | `executable_honest_signed_composition_lifecycle` | **REACHABLE** | 43.428 |
| H04 | health | モデル健全性 | `oclm_phase1c3a_forward_secure_epoch_core.spthy` | `executable_old_certificate_after_later_epoch_compromise` | **REACHABLE** | 21.874 |
| H05 | health | モデル健全性 | `oclm_phase1c4b_rollback_resistant_composition_contract.spthy` | `executable_rollback_resistant_composed_lifecycle` | **REACHABLE** | 2.915 |
| H06 | health | モデル健全性 | `oclm_phase1c5a_revocation_state_core.spthy` | `executable_revocation_lifecycle` | **REACHABLE** | 2.036 |
| H07 | health | モデル健全性 | `oclm_phase1c5b_transparency_split_view_core.spthy` | `executable_transparency_split_view_lifecycle` | **REACHABLE** | 2.083 |
| H08 | health | モデル健全性 | `oclm_phase1c6b_generalized_security_composition_contract.spthy` | `executable_generalized_clean_multi_epoch_lifecycle` | **REACHABLE** | 13.7 |

## 解釈上の限界

この結果は、Phase 1正本ruleの下で、選定した80の形式的崩壊条件へ到達できるかを示します。全通過しても、自然言語で表されたOCLM理論の全主張がモデルへ漏れなく翻訳されていることまでは自動的に証明しません。原典と形式モデルの完全対応は、別途traceability監査で確定する必要があります。
