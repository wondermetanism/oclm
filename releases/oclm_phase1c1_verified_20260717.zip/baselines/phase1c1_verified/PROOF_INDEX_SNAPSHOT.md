# OCLM Verified Proof Index

Date: 2026-07-17

## Phase 1-A — Symbolic Lineage Core

Release:
oclm_phase1a_verified_20260717.zip

SHA-256:
91dfc2d3e32b6c4cdce893f5394beec0a50bb49f3eb8bc37bbaa6870f3434eb3

Guarantees:
- accepted Child has prior generation
- full Oracle and Parent ancestry
- complementary pair single use
- Child lineage binding
- equivocation evidence event

## Phase 1-B1 — External Authenticity

Release:
oclm_phase1b1_verified_20260717.zip

SHA-256:
b2a2d1e872ae94c28273787f20cbf144027cd62288ce28658e28b4df1be9d2b4

Guarantees:
- external acceptance requires generation or prior key compromise
- external Child identity and lineage are bound before compromise

## Phase 1-B2 — Time–Space Window

Release:
oclm_phase1b2_verified_20260717.zip

SHA-256:
912e4cfaf462a5d716168dcb8134c340c99340685c45428f10c64d5286d75cf9

Guarantees:
- Oracle window precedes both Parent participations
- both Parent participations precede Child generation
- generation precedes matching closure
- one issuance window generates at most once

## Phase 1-B3 — Claim-Collapse Independence

Release:
oclm_phase1b3_verified_20260717.zip

SHA-256:
20143ea59382cb31e507a1ea5216c6c23e196bb12f44c8100e58eb04f2eed13b

Guarantees:
- Parent and Consensus claims may collapse
- post-collapse acceptance still requires generation or compromise
- claims and Consensus cannot replace the Child lineage
